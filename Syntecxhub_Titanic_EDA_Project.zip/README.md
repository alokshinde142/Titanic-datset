
# Syntecxhub Project – Titanic Dataset EDA

## Objective
Perform exploratory data analysis on the Titanic dataset.

## Tasks Completed
- Checked data types and missing values
- Analyzed survival rates by sex and passenger class
- Visualized findings using bar charts and boxplots
- Generated an insight report

## Technologies
Python, Pandas, Matplotlib

## Files
titanic_sample.csv – dataset  
titanic_eda_project.py – analysis code  
Generated charts – PNG files  
insights.txt – summary report
