
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("titanic_sample.csv")

print("Dataset Shape:", df.shape)
print("\nData Types:\n", df.dtypes)
print("\nMissing Values:\n", df.isnull().sum())

# Survival by Sex
survival_sex = df.groupby("Sex")["Survived"].mean()

plt.figure()
survival_sex.plot(kind="bar")
plt.title("Survival Rate by Sex")
plt.ylabel("Survival Rate")
plt.xlabel("Sex")
plt.tight_layout()
plt.savefig("survival_by_sex.png")

# Survival by Class
survival_class = df.groupby("Pclass")["Survived"].mean()

plt.figure()
survival_class.plot(kind="bar")
plt.title("Survival Rate by Passenger Class")
plt.ylabel("Survival Rate")
plt.xlabel("Class")
plt.tight_layout()
plt.savefig("survival_by_class.png")

# Age distribution boxplot
plt.figure()
df.boxplot(column="Age", by="Survived")
plt.title("Age Distribution by Survival")
plt.suptitle("")
plt.xlabel("Survived")
plt.ylabel("Age")
plt.tight_layout()
plt.savefig("age_boxplot.png")

# Insight report
report = '''
Key Insights:
1. Survival rate differs significantly between males and females.
2. Higher passenger classes tend to have better survival rates.
3. Age distribution shows variation between survivors and non-survivors.
4. Demographic factors like sex and class strongly influence survival.
'''

with open("insights.txt","w") as f:
    f.write(report)

print("EDA Completed. Charts and insights saved.")
